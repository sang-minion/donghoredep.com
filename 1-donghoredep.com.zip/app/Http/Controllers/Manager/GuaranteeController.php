<?php

namespace App\Http\Controllers\Manager;

use App\Http\Controllers\BaseAdminController;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\model\Category;

class GuaranteeController extends BaseAdminController
{

    public function  __construct()
    {
        parent::__construct();
    }
    public function listView(Request $request){
        $this->menu();
        $this->title('Guarantee');
        $this->breadcrumb([['title' => 'Guarantee', 'link' => route('admin.guarantee'), 'active' => 'active']]);
        $data = Category::getById(Category::getIdByKeyword(\CGlobal::key_bao_hanh_doi_tra));
        return view('manager.guarantee.show',['data'=>$data]);
    }
    public function getItem(Request $request){
        $this->menu();
        $this->title('Guarantee');
        \Loader::loadJS('libs\ckeditor\ckeditor.js');
        $this->breadcrumb([['title' => 'Guarantee', 'link' => route('admin.guarantee'), 'active' => ''],['title' =>'cập nhật', 'link' => \route('admin.guarantee_edit'), 'active' => 'active']]);
        $data = Category::getById(Category::getIdByKeyword(\CGlobal::key_bao_hanh_doi_tra));
        return view('manager.guarantee.add',['data'=>$data]);
    }
    public function postItem(Request $request){
        $data = array();
        $data['category_content'] = addslashes($request->category_content);
        Category::saveItem($data,Category::getIdByKeyword(\CGlobal::key_bao_hanh_doi_tra));
        return redirect()->route('admin.guarantee');
    }
}
