<?php

namespace App\Http\Controllers\Manager;

use App\Http\Controllers\BaseAdminController;
use App\model\Category;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ContactController extends BaseAdminController
{
    public function __construct()
    {
        parent::__construct();
    }
    public function listView(Request $request){
        $this->menu();
        $this->title('Contact');
        $this->breadcrumb([['title' => 'Contact', 'link' => route('admin.contact'), 'active' => 'active']]);
        $data = Category::getById(Category::getIdByKeyword(\CGlobal::key_lien_he));
        return view('manager.contact.show',['data'=>$data]);
    }
    public function getItem(Request $request){
        $this->menu();
        $this->title('Contact');
        \Loader::loadJS('libs\ckeditor\ckeditor.js');
        $this->breadcrumb([['title' => 'Contact', 'link' => route('admin.contact'), 'active' => ''],['title' =>'cập nhật', 'link' => \route('admin.contact_edit'), 'active' => 'active']]);
        $data = Category::getById(Category::getIdByKeyword(\CGlobal::key_lien_he));
        return view('manager.contact.add',['data'=>$data]);
    }
    public function postItem(Request $request){
        $data = array();
        $data['category_intro'] = serialize(['title'=>$request->title,'address'=>$request->address,'phone'=>$request->phone]);
        $data['category_content'] = addslashes($request->category_content);
        Category::saveItem($data,Category::getIdByKeyword(\CGlobal::key_lien_he));
        return redirect()->route('admin.contact');
    }
}
