<?php

namespace App\Http\Controllers\Manager;

use App\Http\Controllers\BaseAdminController;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;

class DashboardController extends BaseAdminController
{
    public function __construct()
    {
        parent::__construct();
    }
    public function listView(Request $request){
        $this->title('Dashboard');
        $this->menu();
        return view('layouts.admin');
    }
}
