<?php

namespace App\Http\Controllers;


use App\model\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

class BaseHomController extends Controller
{
    public function __construct()
    {

    }
    public function menu(Request $request)
    {
        $path = $request->path();
        $arMenu = array();
        $loaidongho = Category::getAll(['category_parent_id'=>Category::getIdByKeyword(\CGlobal::key_danh_muc_dh)],0);
        $tintuc = Category::getById(Category::getIdByKeyword(\CGlobal::key_tin_tuc));
        $lienhe = Category::getById(Category::getIdByKeyword(\CGlobal::key_lien_he));
        if(!empty($loaidongho)) {
            foreach ($loaidongho as $item) {
                if ($item->horizontal_menu == \CGlobal::status_show&&$item->category_status=\CGlobal::status_show) {
                    $arMenu[] = array('title' => $item->category_title, 'link' => route('home.category', ['name' => $item->category_keyword]), 'icon' => '', 'active' => $this->checkPath($path, $item->category_keyword) ? 'active' : '');
                }
            }
        }
        if (!empty($tintuc)&&$tintuc->horizontal_menu==\CGlobal::status_show&&$tintuc->category_status==\CGlobal::status_show){
            $arMenu[] = array('title' => $tintuc->category_title, 'link' => route('home.category',['name'=>$tintuc->category_keyword]), 'icon' => '','active'=>$this->checkPath($path,$tintuc->category_keyword)?'active':'');
        }
        if (!empty($lienhe)&&$lienhe->horizontal_menu==\CGlobal::status_show&&$lienhe->category_status==\CGlobal::status_show){
            $arMenu[] = array('title' => $lienhe->category_title, 'link' => route('home.category',['name'=>$lienhe->category_keyword]), 'icon' => '','active'=>$this->checkPath($path,$lienhe->category_keyword)?'active':'');
        }
        \Loader::loadMenu($arMenu);
        $phone  = Category::getById(Category::getIdByKeyword(\CGlobal::key_lien_he));
        $ar = isset($phone['category_intro']) && $phone['category_intro'] != '' ? unserialize($phone['category_intro']) : array();
        $arPhone = array();
        if (!empty($ar)){
            $arPhone = $ar['phone'];
        }
        \CGlobal::$hosline = !empty($arPhone)?$arPhone[0]:\CGlobal::phoneSupport;
    }
    public function checkPath($path='',$pathcheck = ''){
        $r = false;
        if($path===$pathcheck||strtolower(substr($path,0,strlen($pathcheck)))===strtolower($pathcheck)){
            $r = true;
        }
        return $r;
    }
}
