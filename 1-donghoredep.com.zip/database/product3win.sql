/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50626
Source Host           : localhost:3306
Source Database       : product3win

Target Server Type    : MYSQL
Target Server Version : 50626
File Encoding         : 65001

Date: 2017-06-17 09:11:27
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for advertise
-- ----------------------------
DROP TABLE IF EXISTS `advertise`;
CREATE TABLE `advertise` (
  `advertise_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `advertise_title` text COLLATE utf8_unicode_ci,
  `advertise_intro` text COLLATE utf8_unicode_ci,
  `advertise_media` text COLLATE utf8_unicode_ci,
  `advertise_link` text COLLATE utf8_unicode_ci,
  `advertise_index` tinyint(4) DEFAULT NULL,
  `advertise_category` tinyint(4) DEFAULT NULL,
  `advertise_details` tinyint(4) DEFAULT NULL,
  `advertise_popup` tinyint(4) DEFAULT NULL,
  `advertise_status` int(4) DEFAULT NULL,
  `advertise_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`advertise_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of advertise
-- ----------------------------
INSERT INTO `advertise` VALUES ('3', 'advertise_link', 'http://localhost:8000/donghoredep.vn/admin/advertise/edit\r\nhttp://localhost:8000/donghoredep.vn/admin/advertise/edit\r\nhttp://localhost:8000/donghoredep.vn/admin/advertise/edit', '01-53-26-11-06-2017-18446957772440826276707883381761110907095n.jpg', 'http://localhost:8000/donghoredep.vn/admin/advertise/edit', '1', null, null, null, '1', '1497163204');

-- ----------------------------
-- Table structure for banner
-- ----------------------------
DROP TABLE IF EXISTS `banner`;
CREATE TABLE `banner` (
  `banner_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `banner_title` text COLLATE utf8_unicode_ci,
  `banner_link` text COLLATE utf8_unicode_ci,
  `banner_media` longtext COLLATE utf8_unicode_ci,
  `banner_index` tinyint(4) DEFAULT NULL,
  `banner_category` tinyint(4) DEFAULT NULL,
  `banner_details` tinyint(4) DEFAULT NULL,
  `banner_status` int(11) NOT NULL,
  `banner_created` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`banner_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of banner
-- ----------------------------
INSERT INTO `banner` VALUES ('1', 'banner index', 'https://www.youtube.com/embed/UiuLca2YxBQ', '03-19-50-11-06-2017-166843521001493171758752556464449187198178n.jpg', '1', null, null, '1', '1497168466', null, null);

-- ----------------------------
-- Table structure for category
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `category_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_parent_id` int(11) DEFAULT NULL,
  `category_keyword` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_intro` longtext COLLATE utf8_unicode_ci,
  `category_content` longtext COLLATE utf8_unicode_ci,
  `category_media` longtext COLLATE utf8_unicode_ci,
  `category_created` int(11) DEFAULT NULL,
  `category_status` int(11) DEFAULT NULL,
  `horizontal_menu` tinyint(4) DEFAULT NULL,
  `vertical_menu` tinyint(4) DEFAULT NULL,
  `category_order_no` int(11) DEFAULT NULL,
  `meta_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_keywords` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO `category` VALUES ('5', '0', 'loai-dong-ho', 'Loại đồng hồ', '', '', '', '1497069518', '1', null, null, '1', '', '', '');
INSERT INTO `category` VALUES ('6', '5', 'dong-ho-nu', 'Đồng Hồ Nữ', null, '', '', '1496932865', '1', '1', null, '2', 'dong-ho-nu', 'dong-ho-nu', 'dong-ho-nu');
INSERT INTO `category` VALUES ('7', '5', 'dong-ho-nam', 'Đồ Hồ Nam', null, '', '', '1496932874', '1', '1', null, '3', 'dong-ho-nam', 'dong-ho-nam', 'dong-ho-nam');
INSERT INTO `category` VALUES ('8', '5', 'dong-ho-doi', 'Đồng Hồ Đôi', null, '', '', '1496932881', '0', '1', null, '4', 'dong-ho-doi', 'dong-ho-doi', 'dong-ho-doi');
INSERT INTO `category` VALUES ('9', '0', 'nhan-hieu', 'Nhãn hiệu', '', '', '', '1496932826', '1', null, null, '1', '', '', '');
INSERT INTO `category` VALUES ('10', '0', 'tin-tuc', 'TIN TỨC', '', '', '', '1496932980', '1', '1', null, '1', '', '', '');
INSERT INTO `category` VALUES ('11', '0', 'lien-he', 'LIÊN HỆ', 'a:3:{s:5:\"title\";a:2:{i:0;s:17:\"Trụ sở chính\";i:1;s:6:\"VP.HCM\";}s:7:\"address\";a:2:{i:0;s:55:\"Số 15 ngõ 178 Kim Hoa, quận Đống Đa, Hà Nội\";i:1;s:65:\"122/ 65 Bùi Đinh Tuý, quận Bình Thạnh, TP. Hồ Chí Minh\";}s:5:\"phone\";a:2:{i:0;s:10:\"0988817208\";i:1;s:10:\"0971752847\";}}', '<p><span style=\\\"color:rgb(0, 0, 0); font-family:arial,helvetica,sans-serif\\\">X&atilde; hội ng&agrave;y c&agrave;ng ph&aacute;t triển, cuộc sống ng&agrave;y c&agrave;ng được n&acirc;ng cao, v&agrave; những nhu cầu tiện nghi cho cuộc sống con người cũng v&igrave; thế m&agrave; n&acirc;ng l&ecirc;n, k&egrave;m theo đ&oacute; l&agrave; những th&uacute; vui sưu tầm v&agrave; sở hữu những gi&aacute; trị nghệ thuật ng&agrave;y c&agrave;ng lớn. Đồng hồ từ xưa đến nay lu&ocirc;n l&agrave; biểu tượng của thời gian. Xu hướng hiện nay, đồng hồ kh&ocirc;ng chỉ được sử dụng với &yacute; nghĩa như vậy m&agrave; th&ecirc;m v&agrave;o đ&oacute; n&oacute; c&ograve;n như một thứ trang sức của con người. Donghoredep.COM l&agrave; nơi cung cấp v&agrave; phục vụ tốt nhất về c&aacute;c loại &nbsp;đồng hồ gi&uacute;p kh&aacute;ch h&agrave;ng trang bị cho m&igrave;nh một sản phẩm trang sức &ndash; cũng như vật trang tr&iacute; ho&agrave;n mỹ nhất.</span></p>\r\n\r\n<p><span style=\\\"color:rgb(0, 0, 0); font-family:arial,helvetica,sans-serif\\\"><img alt=\\\"\\\" src=\\\"http://localhost:8000/donghoredep.vn/uploads/filemanager//source/17190691_1618913538120651_7549735871957397964_n.jpg\\\" style=\\\"height:828px; width:552px\\\" /></span></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><span style=\\\"color:rgb(255, 0, 0)\\\">Trong bối cảnh thị trường đồng hồ ở Việt Nam c&ograve;n nhiều bất cập v&agrave; hạn chế:</span></p>\r\n\r\n<p><span style=\\\"color:rgb(255, 0, 0)\\\">- H&agrave;ng kh&ocirc;ng giống trong ảnh khi nhận.</span></p>\r\n\r\n<p><span style=\\\"color:rgb(255, 0, 0)\\\">- Phải chuyển tiền trước nhiều khi mất an to&agrave;n.</span></p>\r\n\r\n<p><span style=\\\"color:rgb(255, 0, 0)\\\">- Bảo h&agrave;nh v&agrave; đổi trả gặp qu&aacute; nhiều kh&oacute; khăn</span></p>\r\n\r\n<p style=\\\"text-align:justify\\\"><strong>Đồng hồ rẻ đẹp .COM ra đời với cam kết:</strong></p>\r\n\r\n<p style=\\\"text-align:justify\\\"><strong>- Giao h&agrave;ng v&agrave; thu tiền tại nh&agrave;.</strong></p>\r\n\r\n<p style=\\\"text-align:justify\\\"><strong>- H&agrave;ng kh&ocirc;ng giống mẫu trong ảnh qu&yacute; kh&aacute;ch được quyền trả v&agrave; ngay lập tức ch&uacute;ng t&ocirc;i sẽ ho&agrave;n tiền lại cho bạn.</strong></p>\r\n\r\n<p style=\\\"text-align:justify\\\"><strong>- Chỉ khi n&agrave;o nhận được h&agrave;ng mới phải trả tiền, d&ugrave; bạn ở bất cứ đ&acirc;u miễn c&oacute; địa chỉ r&otilde; r&agrave;ng. Bạn kh&ocirc;ng phải chuyển tiền trước, kh&ocirc;ng phải mất c&ocirc;ng đi lại.</strong></p>\r\n\r\n<p style=\\\"text-align:justify\\\"><strong>- Gi&aacute; cả tốt nhất.</strong></p>\r\n\r\n<p style=\\\"text-align:justify\\\"><strong>- Chất lượng tốt nhất.</strong></p>\r\n\r\n<p style=\\\"text-align:justify\\\"><strong>- Mẫu m&atilde; đa dạng, đẹp nhưng gi&aacute; cả rất phải chăng.</strong></p>\r\n\r\n<p style=\\\"text-align:justify\\\"><strong>- CAM KẾT GI&Aacute; LU&Ocirc;N RẺ HƠN THỊ TRƯỜNG.</strong></p>\r\n\r\n<p style=\\\"text-align:justify\\\"><strong>V&agrave; hơn tất cả, sự h&agrave;i l&ograve;ng của qu&yacute; kh&aacute;ch ch&iacute;nh l&agrave; th&agrave;nh c&ocirc;ng lớn nhất cho ch&uacute;ng t&ocirc;i.</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p style=\\\"text-align:justify\\\">Kh&aacute;ch h&agrave;ng của Đồng hồ rẻ đẹp .COM c&oacute; thể l&agrave; doanh nh&acirc;n, kỹ sư, b&aacute;c sĩ, nh&acirc;n vi&ecirc;n văn ph&ograve;ng, học sinh, sinh vi&ecirc;n, người lao động phổ th&ocirc;ng&hellip;Ch&uacute;ng t&ocirc;i sẽ cung cấp c&aacute;c sản phẩm đồng hồ chất lượng cao, đa dạng về mẫu m&atilde;, gi&aacute; cả ph&ugrave; hợp với mọi đối tượng kh&aacute;ch h&agrave;ng. Bạn sẽ dễ d&agrave;ng chọn lựa cho m&igrave;nh một sản phẩm đồng hồ ph&ugrave; hợp với nhu cầu, c&aacute; t&iacute;nh v&agrave; đẳng cấp của m&igrave;nh tại&nbsp; Donghoredep.COM.</p>\r\n\r\n<p style=\\\"text-align:justify\\\">&nbsp;</p>\r\n\r\n<p style=\\\"text-align:justify\\\">Đến với ch&uacute;ng t&ocirc;i Qu&yacute; kh&aacute;ch sẽ được chi&ecirc;m ngưỡng thế giới đồng hồ sinh động, hấp dẫn, được kiểm nghiệm thực tế v&agrave; cảm nhận được sự tận t&igrave;nh chu đ&aacute;o về c&aacute;c dịch vụ mua h&agrave;ng.</p>', '', '1496933026', '1', '1', null, '1', '', '', '');
INSERT INTO `category` VALUES ('12', '0', 'huong-dan-mua-hang', 'Hướng dẫn mua hàng', 'a:2:{s:7:\"address\";N;s:5:\"phone\";N;}', '<p><strong>Mua đơn giản nhất</strong>: gọi điện trực tiếp đến ✆ 0971.752.847</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>Mua nhanh nhất</strong>: Nhắn 1 tin nhắn gồm: Họ t&ecirc;n + Địa chỉ + M&atilde; đồng hồ đến ✆&nbsp;Viettel: 0971.752.847</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>Mua ch&iacute;nh x&aacute;c nhất</strong>: Đặt h&agrave;ng tr&ecirc;n website</p>\r\n\r\n<p>-&nbsp;<em><strong>Bước 1</strong></em>: Lựa chọn mẫu đồng hồ ưng &yacute; tr&ecirc;n website: Donghoredep.COM</p>\r\n\r\n<p>-<em><strong>&nbsp;Bước 2</strong></em>: Điền đầy đủ th&ocirc;ng tin v&agrave;o &ocirc; nhập v&agrave; số lượng bạn muốn mua:</p>\r\n\r\n<p>-&nbsp;<em><strong>Bước 3</strong></em>&nbsp;- Gửi đơn h&agrave;ng: Sau khi điền xong bạn bấm v&agrave;o n&uacute;t GỬI ĐƠN H&Agrave;NG</p>\r\n\r\n<p>=&gt;&gt;&gt; v&agrave; vậy l&agrave; XONG, phần c&ograve;n lại để Donghoredep.COM lo!</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>NHẬN H&Agrave;NG</strong></p>\r\n\r\n<p>Sau 2-4 ng&agrave;y bạn đặt h&agrave;ng, đồng hộ bạn mua sẽ được giao tận tay bạn ở nh&agrave; hoặc bất cứ địa điểm n&agrave;o bạn muốn trong giờ h&agrave;nh ch&iacute;nh nh&eacute; (Từ 8h s&aacute;ng đến 17h chiều).</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>THANH TO&Aacute;N</strong></p>\r\n\r\n<p>Thanh to&aacute;n rất đơn giản, khi n&agrave;o nhận được h&agrave;ng bạn chỉ cần gửi tiền cho người giao l&agrave; xong, kh&ocirc;ng cần chuyển khoản, vừa tiết kiệm thời gian vừa an to&agrave;n đ&uacute;ng ko?</p>', '', '1496933140', '1', null, null, '1', '', '', '');
INSERT INTO `category` VALUES ('13', '0', 'bao-hanh', 'Bảo hành - Đổi trả', null, '<p>Th&ocirc;ng tin bảo h&agrave;i d&agrave;i hay ngắn hạn t&ugrave;y v&agrave;o mức gi&aacute; của sản phẩm</p>', '', '1497084503', '1', null, null, '1', '', '', '');
INSERT INTO `category` VALUES ('14', '9', 'dong-ho-longines', 'Đồng hồ longines', null, '', '02-12-29-14-06-2017-logo-longines.jpg', '1497424349', '1', '1', null, '1', 'dong-ho-longines', 'dong-ho-longines', 'dong-ho-longines');

-- ----------------------------
-- Table structure for menu
-- ----------------------------
DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu` (
  `menu_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menu_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `menu_link` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `menu_parent_id` int(11) NOT NULL,
  `menu_order_no` int(11) NOT NULL,
  `menu_created` int(11) NOT NULL,
  `menu_status` int(11) NOT NULL,
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of menu
-- ----------------------------

-- ----------------------------
-- Table structure for migrations
-- ----------------------------
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of migrations
-- ----------------------------
INSERT INTO `migrations` VALUES ('2', '2014_10_12_100000_create_password_resets_table', '1');
INSERT INTO `migrations` VALUES ('4', '2017_05_31_092011_create_role_table', '1');
INSERT INTO `migrations` VALUES ('5', '2017_05_31_092144_create_trash_table', '1');
INSERT INTO `migrations` VALUES ('6', '2017_05_31_092214_create_menu_table', '1');
INSERT INTO `migrations` VALUES ('7', '2017_06_02_085219_create_category_table', '1');
INSERT INTO `migrations` VALUES ('8', '2017_06_02_093858_create_news_table', '1');
INSERT INTO `migrations` VALUES ('10', '2017_05_31_091908_create_modul_table', '2');
INSERT INTO `migrations` VALUES ('11', '2014_10_12_000000_create_users_table', '3');
INSERT INTO `migrations` VALUES ('15', '2017_06_02_095517_create_product_table', '4');
INSERT INTO `migrations` VALUES ('17', '2017_06_11_105629_create_advertise_table', '6');
INSERT INTO `migrations` VALUES ('18', '2017_06_11_112646_create_script', '7');
INSERT INTO `migrations` VALUES ('19', '2017_06_11_143541_create_baner_table', '8');

-- ----------------------------
-- Table structure for module
-- ----------------------------
DROP TABLE IF EXISTS `module`;
CREATE TABLE `module` (
  `module_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `module_controller` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `module_action` longtext COLLATE utf8_unicode_ci,
  `module_status` tinyint(4) DEFAULT NULL,
  `module_order_no` int(11) DEFAULT NULL,
  `module_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`module_id`)
) ENGINE=InnoDB AUTO_INCREMENT=142 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of module
-- ----------------------------
INSERT INTO `module` VALUES ('4', 'Module', 'App\\Http\\Controllers\\Manager\\Module', 'a:4:{i:0;s:8:\"listView\";i:1;s:7:\"getItem\";i:2;s:8:\"postItem\";i:3;s:6:\"delete\";}', '1', '1', '1496713553');
INSERT INTO `module` VALUES ('129', 'App\\Http\\Controllers\\Manager\\Category', 'App\\Http\\Controllers\\Manager\\Category', 'a:4:{i:0;s:8:\"listView\";i:1;s:7:\"getItem\";i:2;s:8:\"postItem\";i:3;s:6:\"delete\";}', '1', null, null);
INSERT INTO `module` VALUES ('130', 'App\\Http\\Controllers\\Manager\\Trash', 'App\\Http\\Controllers\\Manager\\Trash', 'a:4:{i:0;s:8:\"listView\";i:1;s:7:\"getItem\";i:2;s:7:\"restore\";i:3;s:6:\"delete\";}', '1', null, null);
INSERT INTO `module` VALUES ('131', 'App\\Http\\Controllers\\Manager\\Product', 'App\\Http\\Controllers\\Manager\\Product', 'a:4:{i:0;s:8:\"listView\";i:1;s:7:\"getItem\";i:2;s:8:\"postItem\";i:3;s:6:\"delete\";}', '1', null, null);
INSERT INTO `module` VALUES ('132', 'App\\Http\\Controllers\\Manager\\News', 'App\\Http\\Controllers\\Manager\\News', 'a:4:{i:0;s:8:\"listView\";i:1;s:7:\"getItem\";i:2;s:8:\"postItem\";i:3;s:6:\"delete\";}', '1', null, null);
INSERT INTO `module` VALUES ('133', 'App\\Http\\Controllers\\Manager\\Contact', 'App\\Http\\Controllers\\Manager\\Contact', 'a:3:{i:0;s:8:\"listView\";i:1;s:7:\"getItem\";i:2;s:8:\"postItem\";}', '1', null, null);
INSERT INTO `module` VALUES ('134', 'App\\Http\\Controllers\\Manager\\ShoppingGuide', 'App\\Http\\Controllers\\Manager\\ShoppingGuide', 'a:3:{i:0;s:8:\"listView\";i:1;s:7:\"getItem\";i:2;s:8:\"postItem\";}', '1', null, null);
INSERT INTO `module` VALUES ('135', 'App\\Http\\Controllers\\Manager\\Guarantee', 'App\\Http\\Controllers\\Manager\\Guarantee', 'a:3:{i:0;s:8:\"listView\";i:1;s:7:\"getItem\";i:2;s:8:\"postItem\";}', '1', null, null);
INSERT INTO `module` VALUES ('136', 'App\\Http\\Controllers\\Manager\\Advertise', 'App\\Http\\Controllers\\Manager\\Advertise', 'a:4:{i:0;s:8:\"listView\";i:1;s:7:\"getItem\";i:2;s:8:\"postItem\";i:3;s:6:\"delete\";}', '1', null, null);
INSERT INTO `module` VALUES ('137', 'App\\Http\\Controllers\\Manager\\Script', 'App\\Http\\Controllers\\Manager\\Script', 'a:4:{i:0;s:8:\"listView\";i:1;s:7:\"getItem\";i:2;s:8:\"postItem\";i:3;s:6:\"delete\";}', '1', null, null);
INSERT INTO `module` VALUES ('138', 'App\\Http\\Controllers\\Manager\\Banner', 'App\\Http\\Controllers\\Manager\\Banner', 'a:4:{i:0;s:8:\"listView\";i:1;s:7:\"getItem\";i:2;s:8:\"postItem\";i:3;s:6:\"delete\";}', '1', null, null);
INSERT INTO `module` VALUES ('139', 'App\\Http\\Controllers\\Manager\\Role', 'App\\Http\\Controllers\\Manager\\Role', 'a:4:{i:0;s:8:\"listView\";i:1;s:7:\"getItem\";i:2;s:8:\"postItem\";i:3;s:6:\"delete\";}', '1', null, null);
INSERT INTO `module` VALUES ('140', 'App\\Http\\Controllers\\Manager\\Users', 'App\\Http\\Controllers\\Manager\\Users', 'a:3:{i:0;s:8:\"listView\";i:1;s:6:\"delete\";i:2;s:9:\"changeass\";}', '1', null, null);
INSERT INTO `module` VALUES ('141', 'App\\Http\\Controllers\\Manager\\Dashboard', 'App\\Http\\Controllers\\Manager\\Dashboard', 'a:1:{i:0;s:8:\"listView\";}', '1', null, null);

-- ----------------------------
-- Table structure for news
-- ----------------------------
DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `news_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `news_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `news_intro` text COLLATE utf8_unicode_ci,
  `news_content` longtext COLLATE utf8_unicode_ci,
  `news_media` longtext COLLATE utf8_unicode_ci,
  `news_status` tinyint(4) DEFAULT NULL,
  `news_created` int(11) DEFAULT NULL,
  `meta_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_keywords` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`news_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of news
-- ----------------------------
INSERT INTO `news` VALUES ('1', 'sang-minion', '<p>sang-minion</p>', '<p>sang0minion-99</p>', '04-14-29-11-06-2017-166843521001493171758752556464449187198178n.jpg', '1', '1497066892', 'sdvsdv', 'sdvsdv', 'sdvsdv');

-- ----------------------------
-- Table structure for password_resets
-- ----------------------------
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `user_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_user_email_index` (`user_email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of password_resets
-- ----------------------------

-- ----------------------------
-- Table structure for product
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `product_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_code_replace` text COLLATE utf8_unicode_ci,
  `product_cate_id` int(11) DEFAULT NULL,
  `product_brand_id` int(11) DEFAULT NULL,
  `product_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_price_input` int(11) DEFAULT NULL,
  `product_price_saleof` int(11) DEFAULT NULL,
  `product_price` int(11) DEFAULT NULL,
  `product_price_multi` longtext COLLATE utf8_unicode_ci,
  `product_intro` longtext COLLATE utf8_unicode_ci,
  `product_details` longtext COLLATE utf8_unicode_ci,
  `product_order_no` int(11) DEFAULT NULL,
  `product_media` longtext COLLATE utf8_unicode_ci,
  `product_multi_media` longtext COLLATE utf8_unicode_ci,
  `product_video` longtext COLLATE utf8_unicode_ci,
  `product_promotion` text COLLATE utf8_unicode_ci,
  `product_vote` text COLLATE utf8_unicode_ci,
  `product_status` int(4) DEFAULT NULL,
  `product_focus` tinyint(4) DEFAULT NULL,
  `product_host` tinyint(4) DEFAULT NULL,
  `product_buy_most` tinyint(4) DEFAULT NULL,
  `product_cheapest` tinyint(4) DEFAULT NULL,
  `product_created` int(11) DEFAULT NULL,
  `meta_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_keywords` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of product
-- ----------------------------
INSERT INTO `product` VALUES ('2', 'SK-368X', 'a:1:{i:0;N;}', '7', '-1', 'Đồng Hồ Nam SK-368X', null, '299000', '250000', 'a:4:{i:1;s:6:\"250000\";i:2;s:6:\"200000\";i:5;s:6:\"150000\";i:10;s:6:\"100000\";}', '<div style=\\\"margin: 0px; padding: 0px; color: rgb(34, 34, 34); font-stretch: normal; line-height: 19px; font-family: Arial, Helvetica, sans-serif;\\\">- Size: 38mm</div>\r\n\r\n<div style=\\\"margin: 0px; padding: 0px; color: rgb(34, 34, 34); font-stretch: normal; line-height: 19px; font-family: Arial, Helvetica, sans-serif;\\\">- D&agrave;y: 6mm</div>\r\n\r\n<div style=\\\"margin: 0px; padding: 0px; color: rgb(34, 34, 34); font-stretch: normal; line-height: 19px; font-family: Arial, Helvetica, sans-serif;\\\">- Chống nước: &nbsp;3 ATM*</div>\r\n\r\n<div style=\\\"margin: 0px; padding: 0px; color: rgb(34, 34, 34); font-stretch: normal; line-height: 19px; font-family: Arial, Helvetica, sans-serif;\\\">- Chất liệu mặt: k&iacute;nh cường lực chống xước nhẹ</div>\r\n\r\n<div style=\\\"margin: 0px; padding: 0px; color: rgb(34, 34, 34); font-stretch: normal; line-height: 19px; font-family: Arial, Helvetica, sans-serif;\\\">- Chất liệu d&acirc;y: kim loại</div>\r\n\r\n<div style=\\\"margin: 0px; padding: 0px; color: rgb(34, 34, 34); font-stretch: normal; line-height: 19px; font-family: Arial, Helvetica, sans-serif;\\\">- Bảo h&agrave;nh: 6 th&aacute;ng</div>', '<div style=\\\"margin: 0px; padding: 0px; color: rgb(34, 34, 34); font-stretch: normal; line-height: 19px; font-family: Arial, Helvetica, sans-serif; text-align: justify;\\\">- Size: 38mm</div>\r\n\r\n<div style=\\\"margin: 0px; padding: 0px; color: rgb(34, 34, 34); font-stretch: normal; line-height: 19px; font-family: Arial, Helvetica, sans-serif; text-align: justify;\\\">- D&agrave;y: 6mm</div>\r\n\r\n<div style=\\\"margin: 0px; padding: 0px; color: rgb(34, 34, 34); font-stretch: normal; line-height: 19px; font-family: Arial, Helvetica, sans-serif; text-align: justify;\\\">- Chống nước: &nbsp;3 ATM*</div>\r\n\r\n<div style=\\\"margin: 0px; padding: 0px; color: rgb(34, 34, 34); font-stretch: normal; line-height: 19px; font-family: Arial, Helvetica, sans-serif; text-align: justify;\\\">- Chất liệu mặt: k&iacute;nh cường lực chống xước nhẹ</div>\r\n\r\n<div style=\\\"margin: 0px; padding: 0px; color: rgb(34, 34, 34); font-stretch: normal; line-height: 19px; font-family: Arial, Helvetica, sans-serif; text-align: justify;\\\">- Chất liệu d&acirc;y: kim loại</div>\r\n\r\n<div style=\\\"margin: 0px; padding: 0px; color: rgb(34, 34, 34); font-stretch: normal; line-height: 19px; font-family: Arial, Helvetica, sans-serif; text-align: justify;\\\">- Bảo h&agrave;nh: 6 th&aacute;ng</div>', '1', '11-56-57-09-06-2017-1734250210264264107921485276048840815502078n.jpg', 'a:3:{i:0;s:68:\"11-39-00-10-06-2017-1734250210264264107921485276048840815502078n.jpg\";i:1;s:68:\"11-39-00-10-06-2017-1742624810264282507919645033541259084163886n.jpg\";i:2;s:68:\"11-39-00-10-06-2017-1745794810264264041254828812537524041225335n.jpg\";}', 'https://www.youtube.com/embed/waEL5Uwd2n8', '<div style=\\\"margin: 0px; padding: 0px; color: rgb(0, 0, 0); font-stretch: normal; line-height: 19px; font-family: Arial, Helvetica, sans-serif;\\\">- 2 mẫu 2 gi&aacute; bất kỳ đều được t&iacute;nh gi&aacute; mua 2</div>\r\n\r\n<div style=\\\"margin: 0px; padding: 0px; color: rgb(0, 0, 0); font-stretch: normal; line-height: 19px; font-family: Arial, Helvetica, sans-serif;\\\">- Qu&agrave; tặng Mặc định: 2 pin dự ph&ograve;ng</div>\r\n\r\n<div style=\\\"margin: 0px; padding: 0px; color: rgb(0, 0, 0); font-stretch: normal; line-height: 19px; font-family: Arial, Helvetica, sans-serif;\\\">- mua 1 sản phẩm c&oacute; gi&aacute; trị từ 199k hoặc đơn h&agrave;ng từ 250k sẽ được tặng 1 TRONG 2 m&oacute;n qu&agrave; l&agrave; K&Iacute;NH XUYỂN Đ&Ecirc;M hoặc V&Iacute; DA</div>', null, '1', '1', '1', '1', null, '1497026418', 'Đồng hông nam sk368x', 'sk dong-ho-sk', 'sk dong-ho-sk');

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `role_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `role_permission` longtext COLLATE utf8_unicode_ci,
  `role_order_no` int(11) DEFAULT NULL,
  `role_status` tinyint(4) DEFAULT NULL,
  `role_created` int(11) DEFAULT NULL,
  `allow_upload` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES ('11', 'Admin', 'a:12:{s:37:\"App\\Http\\Controllers\\Manager\\Category\";a:4:{s:8:\"listView\";s:4:\"\"1\"/\";s:7:\"getItem\";s:4:\"\"1\"/\";s:8:\"postItem\";s:4:\"\"1\"/\";s:6:\"delete\";s:4:\"\"1\"/\";}s:34:\"App\\Http\\Controllers\\Manager\\Trash\";a:4:{s:8:\"listView\";s:4:\"\"1\"/\";s:7:\"getItem\";s:4:\"\"1\"/\";s:7:\"restore\";s:4:\"\"1\"/\";s:6:\"delete\";s:4:\"\"1\"/\";}s:36:\"App\\Http\\Controllers\\Manager\\Product\";a:4:{s:8:\"listView\";s:4:\"\"1\"/\";s:7:\"getItem\";s:4:\"\"1\"/\";s:8:\"postItem\";s:4:\"\"1\"/\";s:6:\"delete\";s:4:\"\"1\"/\";}s:33:\"App\\Http\\Controllers\\Manager\\News\";a:4:{s:8:\"listView\";s:4:\"\"1\"/\";s:7:\"getItem\";s:4:\"\"1\"/\";s:8:\"postItem\";s:4:\"\"1\"/\";s:6:\"delete\";s:4:\"\"1\"/\";}s:36:\"App\\Http\\Controllers\\Manager\\Contact\";a:3:{s:8:\"listView\";s:4:\"\"1\"/\";s:7:\"getItem\";s:4:\"\"1\"/\";s:8:\"postItem\";s:4:\"\"1\"/\";}s:42:\"App\\Http\\Controllers\\Manager\\ShoppingGuide\";a:3:{s:8:\"listView\";s:4:\"\"1\"/\";s:7:\"getItem\";s:4:\"\"1\"/\";s:8:\"postItem\";s:4:\"\"1\"/\";}s:38:\"App\\Http\\Controllers\\Manager\\Guarantee\";a:3:{s:8:\"listView\";s:4:\"\"1\"/\";s:7:\"getItem\";s:4:\"\"1\"/\";s:8:\"postItem\";s:4:\"\"1\"/\";}s:38:\"App\\Http\\Controllers\\Manager\\Advertise\";a:4:{s:8:\"listView\";s:4:\"\"1\"/\";s:7:\"getItem\";s:4:\"\"1\"/\";s:8:\"postItem\";s:4:\"\"1\"/\";s:6:\"delete\";s:4:\"\"1\"/\";}s:35:\"App\\Http\\Controllers\\Manager\\Script\";a:4:{s:8:\"listView\";s:4:\"\"1\"/\";s:7:\"getItem\";s:4:\"\"1\"/\";s:8:\"postItem\";s:4:\"\"1\"/\";s:6:\"delete\";s:4:\"\"1\"/\";}s:35:\"App\\Http\\Controllers\\Manager\\Banner\";a:4:{s:8:\"listView\";s:4:\"\"1\"/\";s:7:\"getItem\";s:4:\"\"1\"/\";s:8:\"postItem\";s:4:\"\"1\"/\";s:6:\"delete\";s:4:\"\"1\"/\";}s:33:\"App\\Http\\Controllers\\Manager\\Role\";a:2:{s:8:\"listView\";s:4:\"\"1\"/\";s:7:\"getItem\";s:4:\"\"1\"/\";}s:35:\"App\\Http\\Controllers\\Manager\\Module\";a:4:{s:8:\"listView\";s:4:\"\"1\"/\";s:7:\"getItem\";s:4:\"\"1\"/\";s:8:\"postItem\";s:4:\"\"1\"/\";s:6:\"delete\";s:4:\"\"1\"/\";}}', '1', '1', '1496722064', '1');

-- ----------------------------
-- Table structure for script
-- ----------------------------
DROP TABLE IF EXISTS `script`;
CREATE TABLE `script` (
  `script_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `script_title` text COLLATE utf8_unicode_ci,
  `script_content` longtext COLLATE utf8_unicode_ci,
  `post_header` tinyint(4) DEFAULT NULL,
  `post_body` tinyint(4) DEFAULT NULL,
  `post_end` tinyint(4) DEFAULT NULL,
  `script_status` tinyint(4) DEFAULT NULL,
  `script_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`script_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of script
-- ----------------------------
INSERT INTO `script` VALUES ('1', 'mã nhúng facebook', '<script type=\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"text/javascript\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\">\r\n<!--//--><![CDATA[//><!--\r\njQuery.extend(Drupal.settings, {\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"basePath\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"pathPrefix\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"ajaxPageState\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":{\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"theme\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"theme_default\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"theme_token\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"DNhDgyMuRoOHU3nwf3hujtKuKT4V8KBp0XcWQPLb4Wo\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":{\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"misc\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/jquery.js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"misc\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/jquery.once.js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"misc\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/drupal.js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"sites\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/all\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/modules\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/MODULE_DEVELOPER\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModBlocks\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModBlocks.js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"sites\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/all\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/modules\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/MODULE_DEVELOPER\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModBlocks\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/jquery.lazyload.js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"sites\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/all\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/modules\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/MODULE_DEVELOPER\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModBlocks\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ajaxLoadProduct.js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"sites\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/all\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/modules\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/MODULE_DEVELOPER\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModBlocks\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/jquery.vote.js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"sites\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/all\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/modules\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/MODULE_DEVELOPER\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModCaptcha\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModCaptcha.js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"sites\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/all\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/modules\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/MODULE_DEVELOPER\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModContact\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModContact.js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"sites\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/all\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/modules\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/MODULE_DEVELOPER\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModCore\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/core.js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"sites\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/all\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/modules\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/MODULE_DEVELOPER\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModCore\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/jquery.alerts.js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"sites\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/all\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/modules\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/MODULE_DEVELOPER\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModNews\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModNews.js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"sites\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/all\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/modules\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/MODULE_DEVELOPER\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModProduct\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModProduct.js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"sites\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/all\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/themes\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/theme_default\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/responsive.js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1},\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":{\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"modules\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/system\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/system.base.css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"modules\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/system\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/system.menus.css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"modules\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/system\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/system.messages.css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"modules\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/system\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/system.theme.css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"modules\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/comment\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/comment.css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"modules\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/field\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/theme\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/field.css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"modules\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/node\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/node.css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"modules\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/search\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/search.css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"modules\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/user\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/user.css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"sites\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/all\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/modules\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/MODULE_DEVELOPER\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModBlocks\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModBlocks.css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"sites\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/all\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/modules\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/MODULE_DEVELOPER\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModCaptcha\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModCaptcha.css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"sites\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/all\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/modules\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/MODULE_DEVELOPER\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModContact\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModContact.css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"sites\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/all\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/modules\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/MODULE_DEVELOPER\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModCore\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/core.css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"sites\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/all\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/modules\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/MODULE_DEVELOPER\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModDefault\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/default.css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"sites\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/all\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/modules\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/MODULE_DEVELOPER\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModNews\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModNews.css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"sites\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/all\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/modules\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/MODULE_DEVELOPER\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModProduct\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/ModProduct.css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"sites\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/all\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/themes\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/theme_default\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/font-awesome.min.css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"sites\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/all\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/themes\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/theme_default\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/style.css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"sites\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/all\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/themes\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/theme_default\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/mobile.css\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\":1}}});\r\n//--><!]]>\r\n</script>\r\n	<script>\r\n  (function(i,s,o,g,r,a,m){i[\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\'GoogleAnalyticsObject\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\']=r;i[r]=i[r]||function(){\r\n  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),\r\n  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)\r\n  })(window,document,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\'script\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\',\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\'//www.google-analytics.com/analytics.js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\',\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\'ga\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\');\r\n\r\n  ga(\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\'create\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\', \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\'UA-66887384-1\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\', \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\'auto\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\');\r\n  ga(\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\'send\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\', \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\'pageview\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\');\r\n	</script>\r\n	\r\n	<!-- Facebook Pixel Code -->\r\n	<script>\r\n	!function(f,b,e,v,n,t,s)\r\n	{if(f.fbq)return;n=f.fbq=function(){n.callMethod?\r\n	n.callMethod.apply(n,arguments):n.queue.push(arguments)};\r\n	if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version=\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\'2.0\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\';\r\n	n.queue=[];t=b.createElement(e);t.async=!0;\r\n	t.src=v;s=b.getElementsByTagName(e)[0];\r\n	s.parentNode.insertBefore(t,s)}(window,document,\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\'script\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\',\r\n	\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\'https://connect.facebook.net/en_US/fbevents.js\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\');\r\n	 fbq(\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\'init\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\', \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\'1070577376407364\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\'); \r\n	fbq(\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\'track\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\', \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\'PageView\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\');\r\n	</script>\r\n	<noscript>\r\n	 <img height=\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"1\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\" width=\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"1\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\" \r\n	src=\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"https://www.facebook.com/tr?id=1070577376407364&ev=PageView\r\n	&noscript=1\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"/>\r\n	</noscript>', '1', null, null, '0', '1497165881');

-- ----------------------------
-- Table structure for trash
-- ----------------------------
DROP TABLE IF EXISTS `trash`;
CREATE TABLE `trash` (
  `trash_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `trash_obj_id` int(11) DEFAULT NULL,
  `trash_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trash_class` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trash_content` longtext COLLATE utf8_unicode_ci,
  `trash_one_media` longtext COLLATE utf8_unicode_ci,
  `trash_multi_media` longtext COLLATE utf8_unicode_ci,
  `trash_folder_media` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trash_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`trash_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of trash
-- ----------------------------

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_role_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_last_login` int(11) DEFAULT NULL,
  `user_last_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_status` tinyint(4) DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('2', '11', 'Bùi tiến sang minion', 'Hòa bình- Việt nam', '0988817208', '1497596963', '::1', '1', 'tiensang93@gmail.com', '$2y$10$bT1pMo8ROWWIynSSF.3RCuQPzxUvdHkzcyHMhI18z0G1sXwftfix2', '9vIoGcfdKWtUnwoO5u3c3wOQAtrBbKPQdHtm0GffDGpw8tefGfKFdVEXtKTn', '2017-06-07 09:00:53', '2017-06-16 14:09:23');
