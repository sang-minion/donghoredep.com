<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAdvertiseTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('advertise', function (Blueprint $table) {
            $table->increments('advertise_id');
            $table->text('advertise_title')->nullable();
            $table->text('advertise_intro')->nullable();
            $table->text('advertise_media')->nullable();
            $table->text('advertise_link')->nullable();
            $table->tinyInteger('advertise_index')->nullable();
            $table->tinyInteger('advertise_category')->nullable();
            $table->tinyInteger('advertise_details')->nullable();
            $table->tinyInteger('advertise_popup')->nullable();
            $table->integer('advertise_status')->nullable();
            $table->integer('advertise_created')->nullable();
//            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('advertise');
    }
}
