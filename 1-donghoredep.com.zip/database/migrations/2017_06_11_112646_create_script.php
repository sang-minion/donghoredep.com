<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateScript extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('script', function (Blueprint $table) {
            $table->increments('script_id');
            $table->text('script_title')->nullable();
            $table->longText('script_content')->nullable();
            $table->tinyInteger('post_header')->nullable();
            $table->tinyInteger('post_body')->nullable();
            $table->tinyInteger('post_end')->nullable();
            $table->tinyInteger('script_status')->nullable();
            $table->integer('script_created')->nullable();
//            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('script');
    }
}
