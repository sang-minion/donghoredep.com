/**
 * Created by Bui on 05/06/2017.
 */
jQuery(document).ready(function () {
    ADMIN.deleteItem();
    ADMIN.checkAllItem();
    ADMIN.additemActionModul();
    ADMIN.showImgIsSelect();
    ADMIN.restoreItem();
    ADMIN.additemGia();
    ADMIN.additemMa();
    ADMIN.additemADR();
    ADMIN.additemSDT();
    ADMIN.showModalIMG();
});
ADMIN = {
    deleteItem: function () {
        jQuery(document).on('click', '#deleteMoreItem', function () {
            var total = jQuery("input:checked").length;
            if (total == 0) {
                jAlert('Vui lòng chọn ít nhất 1 bản ghi để xóa!', 'Thông báo');
                return false;
            } else {
                jConfirm('Bạn muốn xóa [OK]:Đồng ý [Cancel]:Bỏ qua?)', 'Xác nhận', function (r) {
                    if (r) {
                        jQuery('form#formListItem').submit();
                        return true;
                    }
                });
                return false;
            }
        });
    },
    checkAllItem: function () {
        jQuery(document).on('click', "input#checkAll", function () {
            var checkedStatus = this.checked;
            jQuery("input.checkItem").each(function () {
                this.checked = checkedStatus;
            });
        });
    },
    additemActionModul: function () {
        jQuery(document).on('click', '#themAction', function () {
            var rel = Number(jQuery(this).attr('rel'));
            rel = rel + 1;
            jQuery('#sys_drag_sort_action').append("<li id='sys_div_sort_other_" + rel + "' ><div class='itemAction div_sort_order'>" +
                "<input type='checkbox' checked name='module_action[]' value='' id='valueAction" + rel + "'/>" +
                "<input type='text'  id='nameAction'  class='form-control ' rel='" + rel + "'>" +
                "<i id='xoa' class='fa fa-remove fa-admin red'  rel='" + rel + "'> </i></div></li>");
            jQuery(this).attr('rel', rel);
        });
        jQuery('#sys_drag_sort_action').on('keyup', '#nameAction', function () {
            var txt = jQuery(this).val();
            var rel = jQuery(this).attr('rel');
            jQuery('#valueAction' + rel).val(txt);
        });
        jQuery('#sys_drag_sort_action').on('click', '#xoa', function () {
            var rel = Number(jQuery(this).attr('rel'));
            jQuery("ul").children().remove('#sys_div_sort_other_' + rel);
            rel = rel - 1;
            if (rel <= 0) rel = 0;
            jQuery('#themdapan').attr('rel', rel);
        });
    },
    additemGia: function () {
        jQuery(document).on('click', '#themGIa', function () {
            jQuery('#listGia').append('<li>Giá mua : <input class="form-control level-price" type="number" name="level[]" min="1"  autofocus value="1"> :' +
                '<input class="form-control price" type="number"   autofocus  name="price[]" min="0"><i class="fa fa-remove red fa-admin" id="xoa-gia"></i></li>')
        });
        jQuery(document).on('click', '#xoa-gia', function () {
            jQuery(this).parent('li').remove();
        })
    },
    additemMa: function () {
        jQuery(document).on('click', '#themMa', function () {
            jQuery('#listMa').append('<li class="col-md-6 col-sm-6">' +
                '<input class="form-control" type="text" name="product_code_replace[]" value=""><i class="fa fa-remove fa-admin red" id="xoa-ma"></i></li>');
        });
        jQuery(document).on('click', '#xoa-ma', function () {
            jQuery(this).parent('li').remove();
        })
    },
    additemADR: function () {
        jQuery(document).on('click', '#themADR', function () {
            jQuery('#listADR').append('<li class="col-md-12">' +
                '<input class="form-control" type="text" name="title[]" value="" placeholder="tiêu đề"><input class="form-control" type="text" name="address[]" value="" placeholder="địa chỉ liên hệ"><i class="fa fa-remove fa-admin red" id="xoa-ADR"></i></li>');
        });
        jQuery(document).on('click', '#xoa-ADR', function () {
            jQuery(this).parent('li').remove();
        });
    },
    additemSDT: function () {
        jQuery(document).on('click', '#themSDT', function () {
            jQuery('#listSDT').append('<li class="col-md-12">' +
                '<input class="form-control" type="text" name="phone[]" value="" placeholder="số điện thoại liên hệ"><i class="fa fa-remove fa-admin red" id="xoa-SDT"></i></li>');
        });
        jQuery(document).on('click', '#xoa-SDT', function () {
            jQuery(this).parent('li').remove();
        });
    },
    showImgIsSelect: function () {
        jQuery(document).on('change', '#category_media,#product_media,#news_media,#advertise_media,#banner_media', function () {
            var tt = jQuery(this)[0].files.length > 0 ? jQuery(this)[0].files.length : '';
            jQuery('#fileName').text(tt + ' ảnh đã được chọn');
            jQuery('#privewIMG').empty();
            if (jQuery('#privewIMG').attr('rel') == 1) {
                jQuery('#remove_media').val('1');
            }
            jQuery('#privewIMG').append('<img src="' + window.URL.createObjectURL(jQuery(this)[0].files[0]) + '" width="100%"/>');
        });
        jQuery(document).on('click', '#xoa-media', function () {
            jQuery('#remove_media').val('1');
            jQuery(this).parent('#privewIMG').empty();
        });
        jQuery(document).on('change', '#product_multi_media', function () {
            var f = document.getElementById("product_multi_media");
            var tt = jQuery(this)[0].files.length;
            jQuery('#totalList').text(tt + ' ảnh đã được chọn');
            var listIMG = jQuery('#showListIMG');
            listIMG.find('li').each(function () {
                if (jQuery(this).attr('rel') == 0) {
                    jQuery(this).remove();
                }
            });
            if (tt > 0) {
                for (var i = 0; i < tt; i++) {
                    listIMG.append("<li class='col-md-3 col-sm-4' rel='0'><img src='" + window.URL.createObjectURL(f.files[i]) + "' height='150px'></li>");
                }
            }
        });
        jQuery(document).on('click', '#xoa-multi-media', function () {
            jQuery(this).parent('li').remove();
            jQuery('.btn-option').append('<input type="hidden" id="remove_multi_media" name="remove_multi_media[]" value="' + jQuery(this).attr('rel') + '"/>');
        })
    },
    restoreItem: function () {
        jQuery(document).on('click', '#restoreMoreItem', function () {
            var total = jQuery("input:checked").length;
            if (total == 0) {
                jAlert('Vui lòng chọn ít nhất 1 bản ghi để khôi phục!', 'Thông báo');
                return false;
            } else {
                jConfirm('Bạn muốn khôi phục [OK]:Đồng ý [Cancel]:Bỏ qua?)', 'Xác nhận', function (r) {
                    if (r) {
                        jQuery('#formListItem').attr("action", BASE_URL + "admin/trash/restore");
                        jQuery('#formListItem').submit();
                        return true;
                    }
                });
                return false;
            }
        });
    },
    showModalIMG: function () {
        jQuery('#Modal-IMG').hide();
        jQuery(document).on('click', '#showIMG', function () {
            jQuery('#Modal-IMG').show();
            var src = '';
            if (jQuery(this).is('img')) {
                src = jQuery(this).attr('src');
            } else {
                src = jQuery(this).attr('rel');
            }
            jQuery('#img01').attr('src', src);
            jQuery('#modal-img-caption').text(jQuery(this).attr('title'));
        });
        jQuery('.close').on('click', function () {
            jQuery('#Modal-IMG').hide();
        });
        jQuery(document).on('click', '#Modal-IMG', function () {
            jQuery(this).hide();
        })
    },
}