<?php
/**
 * Created by PhpStorm.
 * User: Bui
 * Date: 05/06/2017
 * Time: 10:00 SA
 */
?>
@extends('layouts.admin')
@section('content')
    <form action="" class="form-horizontal frmAdd" method="POST" id="frmAdd" name="frmAdd"
          enctype="multipart/form-data">
        {{ csrf_field() }}
        <div class="form-group">
            <label for="category_content" class="col-md-2 col-sm-3 control-label">Thông tin bảo hành đổi trả</label>
            <div class="col-md-10 col-sm-9">
                <textarea class="form-control ckeditor  "
                          name="category_content">{{isset($data['category_content'])?stripslashes($data['category_content']):old('category_content')}}</textarea>
            </div>
        </div>
        <div class="form-group">
            <div class="col-lg-12 col-md-12 btn-option">
                <button type="submit" name="txtSubmit" id="buttonSubmit" class="btn btn-primary">Lưu lại</button>
                <button type="reset" class="btn" id="goback">Bỏ qua</button>
            </div>
        </div>
    </form>
@endsection
