<?php
/**
 * Created by PhpStorm.
 * User: Bui
 * Date: 05/06/2017
 * Time: 10:00 SA
 */
?>
@extends('layouts.admin')
@section('content')
    <div class="row menu-option">
        <div class="col-lg-6 col-md-6 col-sm-6"><h5>Thông tin liện hệ</h5></div>
        <div class="col-lg-6 col-md-6 col-sm-6" style="text-align: right">
            <a href="{{route('admin.contact_edit')}}"> <i class="fa fa-edit" title="Cập nhật"></i> </a>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <?php
            $ar = isset($data['category_intro']) && $data['category_intro'] != '' ? unserialize($data['category_intro']) : array();
            $arPhone = array();
            $arAddress = array();
            $arTitle = array();
            if (!empty($ar)) {
                $arPhone = $ar['phone'];
                $arAddress = $ar['address'];
                $arTitle = $ar['title'];
            }
            ?>
        <br>
            <div class="col-md-6 table-responsive">
                <table class="table table-bordered table-hover">
                    <tr>
                        <th width="2%">STT</th>
                        <th>Tiêu đề</th>
                        <th>Địa chỉ văn phòng</th>
                    </tr>
                    @foreach($arAddress as $k=>$adr)
                        <tr>
                            <td>{{$k+1}}</td>
                            <td>{{isset($arTitle[$k])?$arTitle[$k]:''}}</td>
                            <td>{{$adr}}</td>
                        </tr>
                    @endforeach
                </table>
            </div>
            <div class="col-md-6 table-responsive">
                <table class="table table-bordered table-hover">
                    <tr>
                        <th width="2%">STT</th>
                        <th>Số điện thoại liên hệ</th>
                    </tr>
                    @foreach($arPhone as $k=>$p)
                        <tr>
                            <td>{{$k+1}}</td>
                            <td>{{$p}}</td>
                        </tr>
                    @endforeach
                </table>
            </div>
        <div>
            {!! stripcslashes($data->category_content) !!}
        </div>
    </div>
@endsection