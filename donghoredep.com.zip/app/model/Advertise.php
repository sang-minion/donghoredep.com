<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use App\library\PHPDev;

class Advertise extends Model
{
    protected $table = 'advertise';
    protected $primaryKey = 'advertise_id';
    public $timestamps = false;
    const FOLDER = 'advertise';
    protected $fillable = array(
        'advertise_id',
        'advertise_title',
        'advertise_intro',
        'advertise_media',
        'advertise_link',
        'advertise_index',
        'advertise_category',
        'advertise_details',
        'advertise_popup',
        'advertise_status',
        'advertise_created');

    public static function removeCache($id = 0)
    {
        if ($id > 0) {
            Cache::forget(\Memcaches::CACHE_ALL_ADVERTISE);
            Cache::forget(\Memcaches::CACHE_ADVERTISE_ID . $id);
        }
    }

    public static function searchByCondition($search = array(), $limit = 0, $offset = 0, &$total = 0)
    {
        $rs = array();
        try {
            $query = self::where('advertise_id', '>', 0);
            if (isset($search['advertise_title']) && $search['advertise_title'] != '') {
                $query->where('advertise_title', 'like', '%' . $search['advertise_title'] . '%');
            }
            if (isset($search['category_status']) && $search['category_status'] != -1) {
                $query->where('category_status', $search['category_status']);
            }
            $total = $query->count();
            $query->orderby('advertise_created', 'desc');
            $fil_get = isset($search['fil_get']) && $search['fil_get'] != '' ? explode(',', trim($search['fil_get'])) : array();
            if (!empty($fil_get)) {
                $rs = $query->take($limit)->skip($offset)->get($fil_get);
            } else {
                $rs = $query->take($limit)->skip($offset)->get();
            }
            return $rs;
        } catch (\PDOException $e) {
            throw new \PDOException();
        }
    }

    public static function getById($id = 0)
    {
        $rs = \Memcaches::CACHE_ON ? Cache::get(\Memcaches::CACHE_ADVERTISE_ID . $id) : array();
        if (empty($rs)) {
            try {
                $rs = self::find($id);
                if ($rs && \Memcaches::CACHE_ON) {
                    Cache::put(\Memcaches::CACHE_ADVERTISE_ID . $id, $rs, \Memcaches::CACHE_TIME_TO_LIVE_ONE_MONTH);
                }
            } catch (\PDOException $e) {
                throw new \PDOException();
            }
        }
        return $rs;
    }

    public static function getAll($dataget = array(), $limit = 0)
    {
        $rs = \Memcaches::CACHE_ON ? Cache::get(\Memcaches::CACHE_ALL_ADVERTISE) : array();
        $rs  = array();
        if (empty($rs)) {
            try {
                $query = self::where('advertise_id', '>', 0);
                $query->where('advertise_status', \CGlobal::status_show);
                $query->orderby('advertise_created', 'desc');
                $fil_get = isset($dataget['fil_get']) && $dataget['fil_get'] ? explode(',', trim($dataget['fil_get'])) : array();
                if ($limit > 0) {
                    $query->take($limit);
                }
                if (!empty($fil_get)) {
                    $rs = $query->get($fil_get);
                } else {
                    $rs = $query->get();
                }
                if ($rs && \Memcaches::CACHE_ON) {
                    Cache::put(\Memcaches::CACHE_ALL_ADVERTISE, $rs, \Memcaches::CACHE_TIME_TO_LIVE_ONE_MONTH);
                }
            } catch (\PDOException $E) {
                throw new \PDOException();
            }
        }
        return $rs;
    }

    public static function addItem($data = array())
    {
        if (is_array($data) && count($data) > 0) {
            try {
                DB::beginTransaction();
                $item = new self();
                foreach ($data as $k => $v) {
                    $item->$k = $v;
                }
                if ($item->save()) {
                    DB::commit();
                    if ($item->advertise_id && \Memcaches::CACHE_ON) {
                        self::removeCache($item->advertise_id);
                    }
                    return $item->advertise_id;
                }
                DB::commit();
            } catch (\PDOException $e) {
                DB::rollBack();
                echo $e;die;
                throw new \PDOException();
            }
        }
        return false;
    }

    public static function updateItem($data = array(), $id = 0)
    {
        if (is_array($data) && count($data) > 0 && $id > 0) {
            try {
                DB::beginTransaction();
                $item = self::find($id);
                $item->update($data);
                if (isset($item->advertise_id) && $item->advertise_id > 0) {
                    self::removeCache($item->advertise_id);
                }
                DB::commit();
                return true;
            } catch (\PDOException $e) {
                DB::rollBack();
                throw new \PDOException();
            }
        }
        return false;
    }

    public static function deleteItem($id = 0)
    {
        if ($id > 0) {
            try {
                DB::beginTransaction();
                $item = self::find($id);
                if ($item != null) {
                    $item->delete();
                    DB::commit();
                    if (isset($item->advertise_id) && $item->advertise_id > 0) {
                        self::removeCache($item->advertise_id);
                    }
                    return true;
                }
            } catch (\PDOException $e) {
                DB::rollBack();
                throw new \PDOException();
            }
        }
        return false;
    }

    public static function saveItem($data = array(), $id = 0)
    {
        if ($id > 0) {
            return self::updateItem($data, $id);
        } else {
            return self::addItem($data);
        }
    }
}
