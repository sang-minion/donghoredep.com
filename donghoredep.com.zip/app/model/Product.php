<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
class Product extends Model
{
    protected $table = 'product';
    protected $primaryKey = 'product_id';
    public $timestamps  = false;
    const FOLDER = 'product';
    protected $fillable = array(
        'product_id',
        'product_code',
        'product_code_replace',
        'product_cate_id',
        'product_brand_id',
        'product_title',
        'product_price_input',
        'product_price_saleof',
        'product_price',
        'product_price_multi',
        'product_intro',
        'product_details',
        'product_order_no',
        'product_media',
        'product_multi_media',
        'product_video',
        'product_promotion',
        'product_vote',
        'product_status',
        'product_focus',
        'product_host',
        'product_buy_most',
        'product_cheapest',
        'product_created',
        'meta_title',
        'meta_keywords',
        'meta_description');
    public static function removeCache($id=0){
        if ($id>0){
            Cache(\Memcaches::CACHE_ALL_PRODUCT);
            Cache::forget(\Memcaches::CACHE_PRODUCT_ID.$id);
        }
    }
    public static function searchByCondition($search = array(),$limit=0,$offset=0,&$total=0){
        $rs = array();
        try{
            $query = self::where('product_id','>',0);
            if(isset($search['product_title'])&&$search['product_title']!=''){
                $query->where('product_title','like','%'.$search['product_title'].'%');
            }
            if(isset($search['product_code'])&&$search['product_code']!=''){
                $query->where('product_code','like','%'.$search['product_code'].'%');
                $query->orWhere('product_code_replace','like','%'.$search['product_code'].'%');
            }
            if(isset($search['product_cate_id'])&&$search['product_cate_id']!=-1){
                $query->where('product_cate_id',$search['product_cate_id']);
            }
            if(isset($search['product_brand_id'])&&$search['product_brand_id']!=-1){
                $query->where('product_brand_id',$search['product_brand_id']);
            }
            if(isset($search['product_focus'])&&$search['product_focus']!=-1){
                $query->where('product_focus',$search['product_focus']);
            }
            if(isset($search['product_host'])&&$search['product_host']!=-1){
                $query->where('product_host',$search['product_host']);
            }
            if(isset($search['product_buy_most'])&&$search['product_buy_most']!=-1){
                $query->where('product_buy_most',$search['product_buy_most']);
            }
            if(isset($search['product_cheapest'])&&$search['product_cheapest']!=-1){
                $query->where('product_cheapest',$search['product_cheapest']);
            }
            if(isset($search['product_status'])&&$search['product_status']!=-1){
                $query->where('product_status',$search['product_status']);
            }
            $total = $query->count();
            $query->orderby('product_order_no','asc');
            $fil_get = isset($search['fil_get'])&&$search['fil_get']!=''?explode(',',trim($search['fil_get'])):array();
            if (!empty($fil_get)){
                $rs = $query->take($limit)->skip($offset)->get($fil_get);
            }else{
                $rs = $query->take($limit)->skip($offset)->get();
            }
            return $rs;
        }catch (\PDOException $e){
            throw new \PDOException();
        }
    }
    public static function getById($id=0){
        $rs = \Memcaches::CACHE_ON?Cache::get(\Memcaches::CACHE_PRODUCT_ID.$id):array();
        if (empty($rs)){
            try{
                $rs = self::find($id);
                if ($rs && \Memcaches::CACHE_ON){
                    Cache::put(\Memcaches::CACHE_PRODUCT_ID.$id,$rs,\Memcaches::CACHE_TIME_TO_LIVE_ONE_MONTH);
                }
            }catch (\PDOException $e){
                throw new \PDOException();
            }
        }
        return $rs;
    }
    public static function getAll($dataget = array(),$limit = 0){
        $rs = \Memcaches::CACHE_ON?Cache::get(\Memcaches::CACHE_ALL_MODUL):array();
        if (empty($rs)){
            try{
                $query = self::where('product_id','>',0);
                $query->where('product_status',\CGlobal::status_show);
                $query->orderby('product_order_no','asc');
                $fil_get = isset($dataget['fil_get'])&&$dataget['fil_get']?explode(',',trim($dataget['fil_get'])):array();
                if ($limit>0){
                    $query->take($limit);
                }
                if (!empty($fil_get)){
                    $rs = $query->get($fil_get);
                }else{
                    $rs = $query->get();
                }
                if ($rs&&\Memcaches::CACHE_ON){
                    Cache::put(\Memcaches::CACHE_ALL_PRODUCT,$rs,\Memcaches::CACHE_TIME_TO_LIVE_ONE_MONTH);
                }
            }catch (\PDOException $E){
                throw new \PDOException();
            }
        }
        return $rs;
    }
    public static function addItem($data = array()){
        if (is_array($data)&&count($data)>0){
            try{
                DB::beginTransaction();
                $item = new self();
                foreach ($data as $k=>$v){
                    $item->$k=$v;
                }
                if ($item->save()){
                    DB::commit();
                    if ($item->product_id&&\Memcaches::CACHE_ON){
                        self::removeCache($item->product_id);
                    }
                    return $item->product_id;
                }
                DB::commit();
            }catch (\PDOException $e){
                DB::rollBack();
                echo $e;die;
                throw new \PDOException();
            }
        }
        return false;
    }
    public static function updateItem($data = array(),$id=0){
        if(is_array($data)&&count($data)>0&&$id>0){
            try{
                DB::beginTransaction();
                $item = self::find($id);
                $item->update($data);
                if(isset($item->product_id)&&$item->product_id>0){
                    self::removeCache($item->product_id);
                }
                DB::commit();
                return true;
            }catch (\PDOException $e){
                DB::rollBack();
                throw new \PDOException();
            }
        }
        return false;
    }
    public static function deleteItem($id=0){
        if ($id>0){
            try{
                DB::beginTransaction();
                $item = self::find($id);
                if ($item!=null){
                    $item->delete();
                    DB::commit();
                    if (isset($item->product_id)&&$item->product_id>0){
                        self::removeCache($item->product_id);
                    }
                    return true;
                }
            }catch (\PDOException $e){
                DB::rollBack();
                throw new \PDOException();
            }
        }
        return false;
    }
    public static function saveItem($data=array(),$id=0){
        if ($id>0){
            self::updateItem($data,$id);
        }else{
            self::addItem($data);
        }
    }
}
