<?php

namespace App\Http\Controllers\Manager;

use App\Http\Controllers\BaseAdminController;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\model\Category;

class ShoppingGuideController extends BaseAdminController
{
    public function __construct()
    {
        parent::__construct();
    }
    public function listView(Request $request){
        $this->menu();
        $this->title('Shopping guide');
        $this->breadcrumb([['title' => 'Shopping guide', 'link' => route('admin.shoppingguide'), 'active' => 'active']]);
        $data = Category::getById(Category::getIdByKeyword(\CGlobal::key_huong_dan_mua_hang));
        return view('manager.shoppingguide.show',['data'=>$data]);
    }
    public function getItem(Request $request){
        $this->menu();
        $this->title('Shopping guide');
        \Loader::loadJS('libs\ckeditor\ckeditor.js');
        $this->breadcrumb([['title' => 'Shopping guide', 'link' => route('admin.shoppingguide'), 'active' => ''],['title' =>'cập nhật', 'link' => \route('admin.shoppingguide_edit'), 'active' => 'active']]);
        $data = Category::getById(Category::getIdByKeyword(\CGlobal::key_huong_dan_mua_hang));
        return view('manager.shoppingguide.add',['data'=>$data]);
    }
    public function postItem(Request $request){
        $data = array();
        $data['category_intro'] = serialize(['address'=>$request->address,'phone'=>$request->phone]);
        $data['category_content'] = addslashes($request->category_content);
        Category::saveItem($data,Category::getIdByKeyword(\CGlobal::key_huong_dan_mua_hang));
        return redirect()->route('admin.shoppingguide');
    }
}
