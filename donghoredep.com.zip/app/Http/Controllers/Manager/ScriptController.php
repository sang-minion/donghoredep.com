<?php

namespace App\Http\Controllers\Manager;

use App\Http\Controllers\BaseAdminController;
use Illuminate\Http\Request;
use App\model\Script;
use App\model\Trash;
use Illuminate\Routing\Route;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;
use \Pagging;
use \Utility;

class ScriptController extends BaseAdminController
{
    protected $arrStatus = array(-1 => 'Chọn trạng thái', \CGlobal::status_show => 'Hiện', \CGlobal::status_hide => 'Ẩn');

    public function __construct()
    {
        parent::__construct();
    }

    public function listView(Request $request)
    {
        $this->menu();
        $this->title('Script');
        $this->breadcrumb([['title' => 'Script', 'link' => route('admin.script'), 'active' => 'active']]);
        $pageNo = (int)$request->has('page') ? $request->page : 1;
        $pageScroll = \CGlobal::num_scroll_page;
        $limit = \CGlobal::num_record_per_page;
        $offset = ($pageNo - 1) * $limit;
        $search = array();
        $total = 0;

        $search['script_title'] = $request->has('script_title') ? $request->script_title : '';
        $search['script_status'] = (int)$request->has('script_status') ? $request->script_status : -1;
        $dataSearch = Script::searchByCondition($search, $limit, $offset, $total);
//        $total = 5000;
        $paging = $total > 0 ? Pagging::getPager($pageScroll, $pageNo, $total, $limit, $search, $request->url()) : '';

        $optionStatus = Utility::getOption($this->arrStatus, $search['script_status']);

        return view('manager.script.list', ['search' => $search, 'data' => $dataSearch, 'total' => $total, 'paging' => $paging, 'optionStatus' => $optionStatus]);
    }

    public function getItem(Request $request, $id = 0)
    {
        $this->menu();
        $this->title($id == 0 ? 'Thêm Script mới' : 'Cập nhật script');
        $this->breadcrumb([['title' => 'Script', 'link' => \route('admin.script'), 'active' => ''], ['title' => $id == 0 ? 'thêm mới' : 'cập nhật', 'link' => \route('admin.script_edit', ['id' => $id]), 'active' => 'active']]);
        $data = array();
        if ($id > 0) {
            $data = Script::getById($id);
        }
        $optionStatus = Utility::getOption($this->arrStatus, isset($data['script_status']) ? $data['script_status'] : \CGlobal::status_show);
        return view('Manager.script.add', ['id' => $id, 'data' => $data, 'optionStatus' => $optionStatus]);
    }

    public function postItem(Request $request, $id = 0)
    {
        $id = $id == 0 ? $request->id_hidden : $id;
        $this->validate($request, [
            'script_title' => 'required|string',
            'script_status' => 'required|int|min:0']);

        $data = array('script_title' => addslashes($request->script_title),
            'script_content' => addslashes($request->script_content),
            'post_header' => $request->post_header,
            'post_body' => $request->post_body,
            'post_end' => $request->post_end,
            'script_status' => $request->script_status,
            'script_created' => time());

        if ($id > 0) {
            unset($data['script_created']);
        }
        Script::saveItem($data, $id);
        return redirect()->route('admin.script');
    }

    public function delete(Request $request)
    {
        $checkID = $request->checkItem;
        $token = $request->_token;
        if (Session::token() === $token) {
            if (!empty($checkID) && is_array($checkID)) {
                foreach ($checkID as $id) {
                    Trash::addItem($id, Session::get('user')['user_id'], 'App\model\Script', Script::FOLDER, 'script_id', 'script_title', '', '');
                    Script::deleteItem($id);
                }
            }
            return redirect()->route('admin.advertise');
        }
    }
}
