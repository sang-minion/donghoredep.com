<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="<?php echo e(asset('resources/assets/media/favicon.ico ')); ?>">
    <title><?php echo e(CGlobal::$title); ?></title>
<?php echo CGlobal::$extraMeta; ?>

<!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- Styles -->
    <link href="<?php echo e(asset('resources/assets/focus/css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('resources/assets/focus/css/reset.css')); ?>" rel="stylesheet">
    <link src="<?php echo e(asset('resources/assets/libs/zoomIMG/multizoom.css')); ?>"></link>
    <link href="<?php echo e(asset('resources/assets/backend/css/home.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('resources/assets/libs/font-awesome-4.7.0/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <script type="text/javascript">
        var BASE_URL = "<?php echo e(config('app.url')); ?>";
    </script>
    <script src="<?php echo e(asset('resources/assets/focus/js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('resources/assets/focus/js/reset.js')); ?>"></script>
    <script src="<?php echo e(asset('resources/assets/focus/js/focus.js')); ?>"></script>

    <script src="<?php echo e(asset('resources/assets/backend/js/home.js')); ?>"></script>

    <?php echo CGlobal::$extraHeaderCSS; ?>

    <?php echo CGlobal::$extraHeaderJS; ?>

    <?php $__currentLoopData = \App\model\Script::getAll(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($item->post_header==CGlobal::status_show&&$item->script_status==CGlobal::status_show): ?>
            <?php echo $item->script_content; ?>

        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</head>
<body>
<div id="app">
    <div class="container-fluid">
        <div class="row menu">
            <nav class="navbar navbar-default">
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                                data-target=".navbar-collapse">
                            <i class="fa fa-bars fa-2x"></i>
                        </button>
                        <a class="logo navbar-brand visible-xs" href="<?php echo e(url('/')); ?>" title="<?php echo e(config('app.name')); ?>">
                            <img src="<?php echo e(asset('resources/assets/media/top-logo.png')); ?>">
                        </a>
                    </div>
                    <div class="collapse navbar-collapse" id="myNavbar">
                        <ul class="nav navbar-nav navbar-left ">
                            <li class="logocenter hidden-xs hidden-sm hidden-md hidden-lg">
                                <a href="" title=""><img class="icon-zalo"
                                                         src="<?php echo e(asset('resources/assets/media/top-logo.png')); ?>"></img></a>
                            </li>
                            <li class="hotline"><a href="tel:<?php echo e(CGlobal::$hosline); ?>" title="host line">
                                    <img class="icon-phone" src="<?php echo e(asset('resources/assets/media/smart.png')); ?>"></img>
                                    <span><b>Hostline</b><br><span><?php echo e(Funclip::formatPhonenumber(CGlobal::$hosline)); ?></span></span>
                                </a></li>
                            <li class="zalo">
                                <a href="#" title="zalo">
                                    <img class="icon-zalo" src="<?php echo e(asset('resources/assets/media/zalo.png')); ?>"></img>
                                    <span><b>Zalo</b><br><span><?php echo e(Funclip::formatPhonenumber(CGlobal::$hosline)); ?></span></span>
                                </a>
                            </li>
                            <li class="frmsearch">
                                <form class="navbar-form" method="GET" action="">
                                    <div class="input-group">
                                        <input type="text" class="form-control" name="search" id="search"
                                               placeholder="Nhập tên SP cần tìm ...">
                                        <div class="input-group-btn">
                                            <button class="btn btn-default" type="submit">
                                                <i class="fa fa-search"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </li>
                        </ul>
                        <ul class="nav navbar-nav navbar-right">
                            <li class="logocenter hidden-xs ">
                                <a href="" title=""><img class="icon-zalo"
                                                         src="<?php echo e(asset('resources/assets/media/top-logo.png')); ?>"></img></a>
                            </li>
                            <li class="active"><a href="" title="">đh nam</a></li>
                            <li><a href="" title="">đh nữ</a></li>
                            <li><a href="" title="">đh đôi</a></li>
                            <li><a href="" title="">đh đẹp</a></li>
                            <li><a href="" title="">khuyến mại</a></li>
                            <li><a href="" title="">tin tức</a></li>
                            <li class="frmsearch" style="display: none">
                                <form class="navbar-form" method="GET" action="">
                                    <div class="input-group">
                                        <input type="text" class="form-control" name="search" id="search"
                                               placeholder="Nhập tên SP cần tìm ...">
                                        <div class="input-group-btn">
                                            <button class="btn btn-default" type="submit">
                                                <i class="fa fa-search"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>

        </div>
        <div class="row content">
            <?php echo $__env->yieldContent('content'); ?>
            <?php $__currentLoopData = \App\model\Script::getAll(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->post_end==CGlobal::status_show&&$item->script_status==CGlobal::status_show): ?>
                    <?php echo $item->script_content; ?>

                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row footer">

            <section class="footer-1">
                <div class="col-md-offset-4 col-md-4 box-like-facebook" >
                    <img src="<?php echo e(asset('resources/assets/media/box-loke-fb.png')); ?>" style="width: 100%;height: 100%;">
                </div>
            </section>
            <section class="footer-2">
                <div class="container">
                    <div class="col-md-6">
                        <h4 style="text-transform: uppercase">Đồng hồ rẻ đẹp</h4>
                        <ul>
                            <li><b>Trụ sở chính: </b><span>Số 15 ngõ 178 Kim Hoa, quận Đống Đa, Hà Nội</span></li>
                            <li><b>VP.HCM: </b><span>122/ 65 Bùi Đinh Tuý, quận Bình Thạnh, TP. Hồ Chí Minh</span></li>
                            <li><b>Điện thoại: </b><span>097.175.2847</span></li>
                            <li><b>Email: </b><span>hoangthanhquan@gmail.com</span></li>
                            <li><b>Website: </b><span>Http://donghoredep.com</span></li>
                        </ul>
                    </div>
                    <div class="col-md-3">
                        <h4 style="text-transform: uppercase">Hỗ trợ khách hàng</h4>
                        <ul>
                            <li><a href="#">- Hướng dẫn mua hàng</a></li>
                            <li><a href="#">- Hướng dẫn thanh toán</a></li>
                            <li><a href="#">- Phương thức giao hàng</a></li>
                            <li><a href="#">- Chính sách bảo hành</a></li>
                        </ul>
                    </div>
                    <div class="col-md-3">
                        <h4 style="text-transform: uppercase">Chính sách chung</h4>
                        <ul>
                            <li><a href="#">- Chính sách đổi trả hàng</a></li>
                            <li><a href="#">- Chính sách vận chuyển</a></li>
                            <li><a href="#">- Quy định bảo mật</a></li>
                            <li><a href="#">- Tiêu chí bán hàng</a></li>
                        </ul>
                    </div>
                </div>
            </section>
            <section class="footer-3">
                <div class="container">
                    <div class="col-md-4 contact-left">
                        <ul>
                            <li>Copyright © <?php echo e(date('Y',time())); ?> by Đồng Hồ Rẻ Đẹp</li>
                        </ul>
                    </div>
                    <div class="col-md-4 list-contact">
                        <div class="item it-facebook"><a href="#"><i class="fa fa-facebook"></i></a></div>
                        <div class="item it-google"><a href="#"><i class="fa fa-google-plus"></i></a></div>
                        <div class="item it-youtube"><a href="#"><i class="fa fa-youtube-play"></i></a></div>
                    </div>
                    <div class="col-md-4 contact-right">
                        <ul>
                            <li><b>Tổng: </b><span>999999</span></li>
                            <li><b>Online: </b><span>99</span></li>
                        </ul>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <a class="btn-top" href="javascript:void(0);" title="Top" style="display: none"></a>
</div>

<!-- Scripts -->
<?php echo CGlobal::$extraFooterCSS; ?>

<?php echo CGlobal::$extraFooterJS; ?>

</body>
</html>
