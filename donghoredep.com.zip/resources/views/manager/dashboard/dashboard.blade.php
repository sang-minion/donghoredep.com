<?php
/**
 * Created by PhpStorm.
 * User: Bui
 * Date: 07/06/2017
 * Time: 13:54 CH
 */?>
@extends('layouts.admin')
@section('content')
    <h3>Dashboard</h3>
    @endsection